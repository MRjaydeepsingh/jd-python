

import random
list=[]
for i in range(1,12):
    lucky_number= random.randint(1,100)
    list.append(lucky_number)

print(list)